import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:frontend/models/trip.dart';

class ApiService {
  static const String baseUrl =
      'http://localhost:5000/api'; // Replace with your backend URL

  static Future<Map<String, String>> getHeaders(bool authenticated) async {
    final headers = <String, String>{'Content-Type': 'application/json'};
    if (authenticated) {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  static Future<Map<String, dynamic>> signup(
    String username,
    String email,
    String password,
  ) async {
    try {
      print('Attempting signup with: $email'); // Debug log
      final response = await http.post(
        Uri.parse('$baseUrl/auth/signup'),
        headers: await getHeaders(false),
        body: jsonEncode({
          'username': username,
          'email': email,
          'password': password,
        }),
      );

      print('Signup response status: ${response.statusCode}'); // Debug log
      print('Signup response body: ${response.body}'); // Debug log

      if (response.statusCode != 201) {
        throw Exception('Signup failed: ${response.body}');
      }

      return jsonDecode(response.body);
    } catch (e) {
      print('Signup error: $e'); // Debug log
      throw Exception('Failed to sign up: $e');
    }
  }

  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    try {
      print('Attempting login with: $email'); // Debug log
      final response = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: await getHeaders(false),
        body: jsonEncode({'email': email, 'password': password}),
      );

      print('Login response status: ${response.statusCode}'); // Debug log
      print('Login response body: ${response.body}'); // Debug log

      if (response.statusCode != 200) {
        throw Exception('Login failed: ${response.body}');
      }

      final data = jsonDecode(response.body);
      if (data['token'] != null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('token', data['token']);
      }
      return data;
    } catch (e) {
      print('Login error: $e'); // Debug log
      throw Exception('Failed to login: $e');
    }
  }

  static Future<List<Trip>> getAllTrips() async {
    final response = await http.get(
      Uri.parse('$baseUrl/trips'),
      headers: await getHeaders(false),
    );
    print('Get trips response: ${response.body}');
    final List<dynamic> tripList = jsonDecode(response.body)['trips'];
    return tripList.map((json) => Trip.fromJson(json)).toList();
  }

  static Future<Map<String, dynamic>> createTrip(
    Map<String, dynamic> tripData,
  ) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/trips'),
        headers: await getHeaders(true),
        body: jsonEncode(tripData),
      );

      if (response.statusCode != 201) {
        throw Exception('Failed to create trip: ${response.body}');
      }

      final result = jsonDecode(response.body);
      print('Trip creation result: $result');
      return result;
    } catch (e) {
      print('Create trip error: $e'); // Debug log
      throw Exception('Failed to create trip: $e');
    }
  }

  // Implement more API service methods for other features (e.g., fetching single trip)
}
