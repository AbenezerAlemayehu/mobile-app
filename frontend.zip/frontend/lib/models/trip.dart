import 'package:frontend/models/user.dart';

class Trip {
  final String id;
  final User userId;
  final String title;
  final String description;
  final String location;
  final DateTime? startDate;
  final DateTime? endDate;
  final DateTime createdAt;

  Trip({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.location,
    this.startDate,
    this.endDate,
    required this.createdAt,
  });

  factory Trip.fromJson(Map<String, dynamic> json) {
    final userJson = json['userId'] ?? json['user'];
    User user;
    if (userJson is Map<String, dynamic>) {
      user = User.fromJson(userJson);
    } else if (userJson is String) {
      user = User(id: userJson, username: '', email: '');
    } else {
      user = User(id: '', username: '', email: '');
    }

    String? startDateStr = json['startDate']?.toString();
    String? endDateStr = json['endDate']?.toString();
    String? createdAtStr = json['createdAt']?.toString();

    return Trip(
      id: json['_id']?.toString() ?? '',
      userId: user,
      title: json['title']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      location: json['location']?.toString() ?? '',
      startDate:
          (startDateStr != null && startDateStr.isNotEmpty)
              ? DateTime.tryParse(startDateStr)
              : null,
      endDate:
          (endDateStr != null && endDateStr.isNotEmpty)
              ? DateTime.tryParse(endDateStr)
              : null,
      createdAt:
          (createdAtStr != null && createdAtStr.isNotEmpty)
              ? DateTime.parse(createdAtStr)
              : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'description': description,
      'location': location,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
    };
  }
}
